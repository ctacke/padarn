﻿using System;

using System.Collections.Generic;
using System.Text;
using OpenNETCF.Web;
using System.Diagnostics;

namespace SampleSite.Handlers
{
    public abstract class BaseHandler : IHttpHandler
    {
        public virtual void ProcessRequest(HttpContext context)
        {
            Debug.WriteLine(string.Format("{0} received {1} at {2}",
                this.GetType().Name,
                context.Request.RequestType,
                context.Request.Path));
        }

        protected string GetEntityName(string path)
        {
            int index = path.IndexOf('/', 1);

            if (index < 0) return null;

            return path.Substring(1, index - 1);
        }
    }
}
