﻿using System;

using System.Collections.Generic;
using System.Text;
using OpenNETCF.Web;

namespace SampleSite.Handlers
{
    // UPDATE
    public class PutHandler : BaseHandler
    {
        public override void ProcessRequest(HttpContext context)
        {
            base.ProcessRequest(context);
        }
    }
}
