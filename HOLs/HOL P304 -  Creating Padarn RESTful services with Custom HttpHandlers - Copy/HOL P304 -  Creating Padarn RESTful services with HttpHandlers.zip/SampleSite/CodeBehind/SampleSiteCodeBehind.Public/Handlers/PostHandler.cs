﻿using System;

using System.Collections.Generic;
using System.Text;
using OpenNETCF.Web;

namespace SampleSite.Handlers
{
    // CREATE
    public class PostHandler : BaseHandler
    {
        public override void ProcessRequest(HttpContext context)
        {
            base.ProcessRequest(context);
        }
    }
}
