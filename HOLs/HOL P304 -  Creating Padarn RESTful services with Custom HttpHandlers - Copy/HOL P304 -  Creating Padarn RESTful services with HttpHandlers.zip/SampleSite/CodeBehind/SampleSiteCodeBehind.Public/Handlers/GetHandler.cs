﻿using System;

using System.Collections.Generic;
using System.Text;
using OpenNETCF.Web;
using System.Diagnostics;

namespace SampleSite.Handlers
{
    // READ
    public class GetHandler : BaseHandler
    {
        public override void ProcessRequest(HttpContext context)
        {
            base.ProcessRequest(context);
        }
    }
}
