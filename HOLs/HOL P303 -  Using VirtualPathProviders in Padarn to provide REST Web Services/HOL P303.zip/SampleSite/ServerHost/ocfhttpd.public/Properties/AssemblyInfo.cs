﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("OpenNETCF Web Server Codenamed \"Padarn\"")]
[assembly: AssemblyDescription("")]
#if DEBUG
[assembly: AssemblyConfiguration("DEBUG")]
#else
[assembly: AssemblyConfiguration("RETAIL")]
#endif
[assembly: AssemblyCompany("OpenNETCF Consulting, LLC")]
[assembly: AssemblyProduct("OpenNETCF Web Server Codenamed \"Padarn\"")]
[assembly: AssemblyCopyright("Copyright © 2007 OpenNETCF Consulting, LLC")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("3dbd4c93-e52b-43cd-8ee2-bf72bee483ab")]
[assembly: AssemblyVersion("1.0.20709.15")]

